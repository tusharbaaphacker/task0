const menuIcon = document.getElementById('menu-icon');
const navLinks = document.getElementById('nav-links');

menuIcon.addEventListener('click', () => {
    navLinks.classList.toggle('active');
});

window.addEventListener("load", function() {
    const section = document.getElementById('popup-section');
    section.style.animation = 'popIn 1.2s ease-out';
});

// Function to animate numbers
function animateNumber(id, start, end, duration) {
    let element = document.getElementById(id);
    let startTime = null;

    function step(timestamp) {
        if (!startTime) startTime = timestamp;
        let progress = timestamp - startTime;
        let current = Math.min(Math.floor(progress / duration * (end - start) + start), end);
        element.textContent = current;
        if (current < end) {
            window.requestAnimationFrame(step);
        }
    }

    window.requestAnimationFrame(step);
}

// Trigger the animation for all numbers
window.onload = function() {
    animateNumber("customers", 0, 689, 2000);
    animateNumber("chefs", 0, 107, 2000);
    animateNumber("events", 0, 253, 2000);
};

document.addEventListener('DOMContentLoaded', function() {
    const menuItems = document.querySelectorAll('.menu-item');

    // Function to show items when they are in view
    function showItems() {
        menuItems.forEach(item => {
            const rect = item.getBoundingClientRect();
            if (rect.top <= window.innerHeight) {
                item.classList.add('show');
            }
        });
    }

    // Trigger the function when scrolling
    window.addEventListener('scroll', showItems);

    // Run the function immediately to check if any items are already in view
    showItems();
});


document.addEventListener("DOMContentLoaded", function() {
    const cards = document.querySelectorAll('.blog-card');
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, { threshold: 0.1 });

    cards.forEach(card => {
        observer.observe(card);
    });
});